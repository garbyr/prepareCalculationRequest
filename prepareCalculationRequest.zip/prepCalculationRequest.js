// dependencies
const aws = require('aws-sdk');
aws.config.update({ region: 'eu-west-1' });


exports.handler = (event, context, callback) => {
    //parse the event from SNS
    console.log(event.Records[0].Sns.Message);
    var messageObj = event.Records[0].Sns.Message;
    var message = JSON.parse(messageObj);
    console.log(JSON.stringify(messageObj));
    console.log(messageObj);
    //execute function 
    mainProcess(context, event, message.requestUUID, message.ICIN, message.NAV, message.dateSequence, message.dateTime, message.yearWeek, message.category, message.calcType, message.description, message.user);
}


sendLambdaSNS = function (event, context, message, topic, subject) {
    var sns = new aws.SNS();
    var params = {
        Message: JSON.stringify(message),
        Subject: subject,
        TopicArn: topic
    };
    sns.publish(params, context.done);
    return null;
}


mainProcess = function (context, event, requestUUID, ICIN, NAV, dateSequence, dateTime, yearWeek, category, calcType, description, user) {
    //write to the database
    var doc = require('aws-sdk');
    var dynamo = new doc.DynamoDB.DocumentClient();
    console.log(yearWeek);
    var yearWeekFloor = (yearWeek - 500);
    console.log(yearWeekFloor);
    var params = {
        TableName: 'NavHistory',
        // IndexName: 'index_name', // optional (if querying an index)

        // Expression to filter on indexed attributes
        KeyConditionExpression: '#hashkey = :hk_val AND #rangekey > :rk_val',
        ExpressionAttributeNames: {
            '#hashkey': 'ICIN',
            '#rangekey': 'YearWeek',
        },
        ExpressionAttributeValues: {
            ':hk_val': ICIN,
            ':rk_val': yearWeekFloor,
        }
    };
    dynamo.query(params, function (err, data) {
        if (err) {
            console.log("ERROR", err);
            context.fail();
        }
        else {
            console.log("SUCCESS", data);
            //sort out the array
            var navArray= data.Items;
            //publish to SNS
            var message = {
                updateShareClassDetail: "Yes",
                updateShareClassAudit: "Yes",
                requestUUID: requestUUID,
                ICIN: ICIN,
                yearWeek: yearWeek,
                category: category,
                calcType: calcType,
                description: description,
                user: user,
                navArray: navArray
            };
            sendLambdaSNS(event, context, message, "someTopic", "calculation request");
        }
    });
}